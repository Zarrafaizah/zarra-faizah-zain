<?php 
include "koneksi.php";
$kode=$_GET['kode'];
$query=mysql_query("select * from barang where kode='$kode'");
?>
<html><head><title>Halaman Edit Data Barang</title><head><body>
<form action="editbarang.php" method="post">
<table border="0">
<?php
while($row=mysql_fetch_array($query)){
?>
<input type="Hidden" name="no" value="<?php echo $no;?>" />
<h2>Data Barang</h2>
<table><tr>
<td>Kode Barang</td>
<td>: <input type="text" name="kode" value="<?php echo $row['kode'];?>" size="10"></td>
</tr>
<tr>
<td>Nama Barang</td>
<td>: <input type="text" name="namabarang" value="<?php echo $row['namabarang'];?>"size="30"></td>
</tr>
<tr>
<td>Harga Satuan</td>
<td>: <input type="text" name="harga" value="<?php echo $row['harga'];?>"size="20"></td>
</tr>
<tr>
<td colspan=2><input type="submit" value="Update"></td>
</tr>
<?php } ?>
</table></form>

</body></html>