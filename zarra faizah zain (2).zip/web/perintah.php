// membaca id artikel
$idartikel = abs((int) $_GET['id']);
