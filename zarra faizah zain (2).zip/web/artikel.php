<!doctype>
<html>
	<head>
		<title>EXO</title>
		<link rel='stylesheet' href='theme/css/style.css'/>
	</head>
	
	<body>
	<!-- Main Header -->
		<div class='main-header'>
			<h2>SELAMAT DATANG DI TOKO ONLINE</h2>
		</div>
		<nav>
			<ul>
				
				<li><a href='artikel.html'>Artikel</a></li>
			</ul>
		</nav>
	<!--Container-->
		<div class='container'>
			<div class='main-wrapper'>
				<div class='left'>
					
						<h2>TOKO ONLINE</h2>
						<p class='justify'>Semoga web ini dapat bermanfaat untuk anda yang ingin belanja namun malas untuk keluar rumah</p>
						
					</div>
				</div>
					<div class='title'>
						<h3>Login Area</h3>
					</div>
					<div class='widget'>
						<form method='POST' action='#'>
							<input type='text' name='username' placeholder='Username...'/><br/><br/>
							<input type='password' name='password' placeholder='*******'/><br/><br/>
							<input type='submit' value='Login !' class='button'>
						</form>
					</div>
				</div>
				
			</div>
			<div class='footer'>
			
			</div>
		</div>
	<script src='theme/js/jquery.js'></script>
	<script>
	$(function(){
		$(".slider img:gt(0)").hide();S
		setInterval(function(){
		$(".slider img:first-child")
		.fadeOut()
		.next(this)
		.fadeIn()
		.end()
		.appendTo(".slider");
		},3000);
	});
	</script>
	</body>
</html>