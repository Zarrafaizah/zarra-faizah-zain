<?php ob_start();
 include "koneksi.php";
 mysql_query("delete from barang where kode='$_GET[kode]'");
 header('location:tampilbarang.php');

?>